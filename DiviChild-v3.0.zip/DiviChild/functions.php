<?php
// Prevent direct file access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ----------------------------------------------------------------------
// 1. STYLES & ENQUEUEING
// ----------------------------------------------------------------------

// Load child theme styles (Divi loads parent styles by default)
add_action( 'wp_enqueue_scripts', 'my_theme_enqueue_styles' );
function my_theme_enqueue_styles() {
    wp_enqueue_style(
        'child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array(),
        wp_get_theme()->get( 'Version' )
    );
}

// ----------------------------------------------------------------------
// 2. SECURITY ENHANCEMENTS
// ----------------------------------------------------------------------

// Remove WP version from RSS feeds
function remove_wp_version_rss() {
    return '';
}
add_filter( 'the_generator', 'remove_wp_version_rss' );

// Remove version parameter from CSS and JS (Frontend only)
function vc_remove_wp_ver_css_js( $src ) {
    if ( is_admin() ) {
        return $src;
    }
    if ( strpos( $src, 'ver=' ) ) {
        $src = remove_query_arg( 'ver', $src );
    }
    return $src;
}
add_filter( 'style_loader_src', 'vc_remove_wp_ver_css_js', 9999 );
add_filter( 'script_loader_src', 'vc_remove_wp_ver_css_js', 9999 );

// Protect against user enumeration via author archives
function author_page_redirect() {
    if ( is_author() ) {
        wp_redirect( home_url() );
        exit;
    }
}
add_action( 'template_redirect', 'author_page_redirect' );

// Disable XML-RPC functionality
add_filter( 'xmlrpc_enabled', '__return_false' );

// Hide detailed login errors to prevent user disclosure
add_filter( 'login_errors', function() {
    return 'Invalid username or password.';
});

// ----------------------------------------------------------------------
// 3. PERFORMANCE & CLEANUP
// ----------------------------------------------------------------------

// Remove unnecessary header links
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'wp_shortlink_wp_head' );

// Disable WP Emojis script and styles
function custom_disable_emojis() {
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );
    remove_action( 'admin_print_styles', 'print_emoji_styles' );
    remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
    remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
    remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
}
add_action( 'init', 'custom_disable_emojis' );

// ----------------------------------------------------------------------
// 4. MEDIA & FILE UPLOADS
// ----------------------------------------------------------------------

// Allow uploading SVG files in Media Library
function custom_upload_mimes( $existing_mimes ) {
    $existing_mimes['svg'] = 'image/svg+xml';
    return $existing_mimes;
}
add_filter( 'mime_types', 'custom_upload_mimes' );